package question1;

public class PrintProduct {

    private Product product;

    public PrintProduct(Product product) {

        this.product = product;

    }

    public void PrintTotalSales() {

        System.out.println("TOTAL PRODUCT SALES: "
                + product.GetTotalProductsSold());

    }

    public void PrintAverageSales() {

        System.out.println("AVERAGE PRODUCT SALES: "
                + (int)product.GetAverageProductSold());

    }

    public void PrintMostPopularProduct() {

        System.out.println("MOST POPULAR PRODUCT: "
                + product.GetMostPopularProduct());

    }

}