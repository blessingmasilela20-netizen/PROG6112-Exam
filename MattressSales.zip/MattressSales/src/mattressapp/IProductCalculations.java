package mattressapp;

public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}